from django.contrib import admin
from database.models import  OdinaryUsesr,Dynamics,Comments,Bookmarks,Barage,Friends,Thumbups
# Register your models here.
""""from django.db import models

# Create your models here.
class OdinaryUsesr(models.Model):
    user_id=models.CharField(max_length=50)
    user_password = models.CharField(max_length=50)
    create_at=models.DateTimeField()
    update_at = models.DateTimeField()
    user_email=models.EmailField()
    def __str__(self):
     return u'%s ' % (self.user_id)

class Dynamics(models.Model):
    post_title=models.CharField(max_length=50)
    content=models.CharField(max_length=200)
    create_at = models.DateTimeField()
    update_at = models.DateTimeField()
    author_id=models.ForeignKey(OdinaryUsesr,on_delete=models.CASCADE)
    def __str__(self):
     return u'%s %s' % (self.post_title,self.content)

class Comments(models.Model):
    author_id = models.ForeignKey(OdinaryUsesr, on_delete=models.CASCADE)
    post_id=models.IntegerField()
    create_at = models.DateTimeField()
    update_at = models.DateTimeField()
    content = models.CharField(max_length=500)
    def __str__(self):
     return u'%s %s' % (self.post_title,self.content)

class Bookmarks(models.Model):
    author_id = models.ForeignKey(OdinaryUsesr, on_delete=models.CASCADE)
    post_id = models.IntegerField()
    create_at = models.DateTimeField()
    update_at = models.DateTimeField()
    url=models.URLField()
    tag=models.CharField(max_length=100)
    def __str__(self):
     return u'%s %s' % (self.tag,self.url)

class Barage(models.Model):
    author_id = models.ForeignKey(OdinaryUsesr, on_delete=models.CASCADE)
    video_id = models.IntegerField()
    create_at = models.DateTimeField()
    update_at = models.DateTimeField()
    barage_time=models.DateTimeField()
    barage_size=models.IntegerField()
    barage_font=models.IntegerField()
    barage_loc=models.CharField(max_length=50)
    barage_conten=models.CharField(max_length=100)

    def __str__(self):
        return u'%s %s %s' % (self.author_id, self.video_id,self.barage_conten)


class Friends(models.Model):
    author_id=models.ForeignKey(OdinaryUsesr,related_name='Friend_author_id',on_delete=models.CASCADE)
    frenid_id=models.ForeignKey(OdinaryUsesr,related_name='Friend_friend_id',on_delete=models.CASCADE)
    create_at = models.DateTimeField()
    update_at = models.DateTimeField()
    frenid_type=models.IntegerField()

    def __str__(self):
        return u'%s %s %s' % (self.author_id, self.frenid_id, self.frenid_type)

class Thumbups(models.Model):
    create_at = models.DateTimeField()
    update_at = models.DateTimeField()
    author_id = models.ForeignKey(OdinaryUsesr, on_delete=models.CASCADE)
    post_id=models.IntegerField()
    def __str__(self):
        return u'%s ' % (self.author_id)

"""
class OdinaryUserAdmin(admin.ModelAdmin):
    list_display = ('user_id','user_email',)
    search_fields = ('user_id', 'user_email',)
    list_filter = ('create_at',)
    date_hierarchy = 'create_at'
    ordering = ('-create_at',)
    fields = ('user_id','user_password','user_email',)


class DynamicsAdmin(admin.ModelAdmin):
    list_display = ('post_title', 'author_id','content',)
    search_fields = ('post_title', 'author_id')
    list_filter = ('create_at',)
    date_hierarchy = 'create_at'
    ordering = ('-create_at',)
    fields = ('author_id', 'post_title', 'content',)

class CommentsAdmin(admin.ModelAdmin):
    list_display = ('author_id','post_id','content',)
    search_fields = ('author_id', 'post_id','content,')
    list_filter = ('create_at',)
    date_hierarchy = 'create_at'
    ordering = ('-create_at',)
    fields = ('author_id', 'post_id', 'content',)
class BookmarksAdmin(admin.ModelAdmin):
    list_display = ('author_id', 'post_id', 'tag','url',)
    search_fields = ('author_id',)
    list_filter = ('create_at',)
    date_hierarchy = 'create_at'
    ordering = ('-create_at',)
    fields = ('author_id', 'post_id', 'url','tag',)

class BarageAdmin(admin.ModelAdmin):
    list_display = ('author_id','video_id','barage_content',)
    search_fields = ('author_id','video_id',)
    list_filter = ('create_at',)
    date_hierarchy = 'create_at'
    ordering = ('-create_at',)
    fields = ('author_id', 'video_id','barage_content',)
class FriendsAdmin(admin.ModelAdmin):
    list_display = ('author_id','friend_id','friend_type',)
    search_fields = ('author_id',)
    list_filter = ('create_at',)
    date_hierarchy = 'create_at'
    ordering = ('-create_at',)
    fields = ('author_id','friend_id','friend_type',)
class ThumbupsAdmin(admin.ModelAdmin):
    list_display = ('author_id',)
    search_fields = ('author_id',)
    list_filter = ('create_at',)
    date_hierarchy = 'create_at'
    ordering = ('-create_at',)
    fields = ('author_id', )



admin.site.register(OdinaryUsesr,OdinaryUserAdmin)
admin.site.register(Dynamics,DynamicsAdmin)
admin.site.register(Comments,CommentsAdmin)
admin.site.register(Bookmarks,BookmarksAdmin)
admin.site.register(Barage,BarageAdmin)
admin.site.register(Friends,FriendsAdmin)
admin.site.register(Thumbups,ThumbupsAdmin)