from django.db import models
from database.models import OdinaryUsesr,Dynamics,Comments,Bookmarks,Barage,Friends,Thumbups

# Create your models here.
